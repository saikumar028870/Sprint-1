package com.digitalbook.author.exception;

public class AuthorException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}

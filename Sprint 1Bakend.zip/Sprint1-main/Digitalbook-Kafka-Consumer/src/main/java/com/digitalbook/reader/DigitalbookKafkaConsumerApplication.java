package com.digitalbook.reader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalbookKafkaConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalbookKafkaConsumerApplication.class, args);
	}

}

package com.digitalbook.reader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalbookKafkaConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
